﻿namespace questionnaire.questionnaire.DTOs
{
    public class CreateQuestionnaire
    {
        public string Title { get; set; }
    }

}
