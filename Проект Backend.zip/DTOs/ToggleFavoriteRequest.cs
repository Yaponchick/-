﻿namespace Web.DTOs
{
    public class ToggleFavoriteRequest
    {
        public bool IsFavorite { get; set; }
    }
}
