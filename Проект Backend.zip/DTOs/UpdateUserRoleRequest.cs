﻿namespace questionnaire.questionnaire.DTOs
{
    public class UpdateUserRoleRequest
    {
        public string Role { get; set; } = null!;
    }
}
