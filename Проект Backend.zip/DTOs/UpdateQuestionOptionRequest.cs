﻿namespace questionnaire.questionnaire.DTOs
{
    public class UpdateQuestionOptionRequest
    {
        public string NewOptionText { get; set; }
    }
}
