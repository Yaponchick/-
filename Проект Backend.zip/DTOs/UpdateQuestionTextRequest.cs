﻿namespace questionnaire.questionnaire.DTOs
{
    public class UpdateQuestionTextRequest
    {
        public string NewText { get; set; } = null!;
    }
}
