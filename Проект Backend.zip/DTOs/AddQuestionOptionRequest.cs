﻿namespace questionnaire.questionnaire.DTOs
{
    public class AddQuestionOptionRequest
    {
        public string OptionText { get; set; } = null!;
    }
}
