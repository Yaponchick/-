﻿using System;
using System.Collections.Generic;
using System.Data;

namespace Web.Models;

public partial class Anonymous
{
    public int Id { get; set; }
    public Guid SessionId { get; set; }
    public DataSetDateTime CreatedAt { get; set; }
}
