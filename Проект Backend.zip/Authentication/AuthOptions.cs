﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.Security.Claims;
using System.Text;

namespace questionnaire.questionnaire.Authentication
{
    public class AuthOptions
    {
        public const string ISSUER = "MyAuthServer";
        public const string AUDIENCE = "MyAuthClient";
        public const string KEY = "mysupersecret_s1234567890123456ecretkey!";
        public const int LIFETIME = 10000;
        public static string UserIdClaimType = "userId";
        public static string RoleClaimType = "role";

        // Константы для имен ролей
        public const string AdminRole = "Admin";
        public const string CreatorRole = "Creator";
        public const string RespondentRole = "Respondent";

        // Константы для ID ролей
        public const int AdminRoleId = 1;
        public const int CreatorRoleId = 2;
        public const int RespondentRoleId = 3;

        public static SymmetricSecurityKey GetSymmetricSecurityKey()
        {
            return new SymmetricSecurityKey(Encoding.UTF8.GetBytes(KEY));
        }

        public static string GetRoleName(int accessLevelId)
        {
            return accessLevelId switch
            {
                AdminRoleId => AdminRole,
                CreatorRoleId => CreatorRole,
                RespondentRoleId => RespondentRole,
                _ => RespondentRole
            };
        }

        public static int GetRoleId(string roleName)
        {
            return roleName.ToLower() switch
            {
                "admin" => AdminRoleId,
                "creator" => CreatorRoleId,
                "respondent" => RespondentRoleId,
                _ => RespondentRoleId
            };
        }

        public static bool IsAdmin(int accessLevelId)
        {
            return accessLevelId == AdminRoleId;
        }

        public static bool CanCreateQuestionnaires(int accessLevelId)
        {
            return accessLevelId == AdminRoleId || accessLevelId == CreatorRoleId;
        }

        public static bool CanRespondToQuestionnaires(int accessLevelId)
        {
            return accessLevelId == AdminRoleId ||
                   accessLevelId == CreatorRoleId ||
                   accessLevelId == RespondentRoleId;
        }

        public static Dictionary<int, string> GetAllRoles()
        {
            return new Dictionary<int, string>
            {
                { AdminRoleId, AdminRole },
                { CreatorRoleId, CreatorRole },
                { RespondentRoleId, RespondentRole }
            };
        }

        public static int? GetCurrentUserRoleId(HttpContext context)
        {
            var roleClaim = context.User.FindFirst(ClaimTypes.Role)?.Value
                           ?? context.User.FindFirst("role")?.Value;

            if (string.IsNullOrEmpty(roleClaim)) return null;

            return GetRoleId(roleClaim);
        }

        public static bool IsCurrentUserAdmin(HttpContext context)
        {
            var roleId = GetCurrentUserRoleId(context);
            return roleId.HasValue && roleId.Value == AdminRoleId;
        }

        public static bool CanCurrentUserCreate(HttpContext context)
        {
            var roleId = GetCurrentUserRoleId(context);
            return roleId.HasValue && CanCreateQuestionnaires(roleId.Value);
        }

        public static int? GetCurrentUserId(HttpContext context)
        {
            var userIdClaim = context.User.FindFirst(UserIdClaimType)?.Value;
            if (int.TryParse(userIdClaim, out int userId))
            {
                return userId;
            }
            return null;
        }

        // Кастомные атрибуты авторизации
        public class AdminAuthorizeAttribute : AuthorizeAttribute
        {
            public AdminAuthorizeAttribute()
            {
                Roles = AdminRole;
            }
        }

        public class CreatorAuthorizeAttribute : AuthorizeAttribute
        {
            public CreatorAuthorizeAttribute()
            {
                Roles = $"{AdminRole},{CreatorRole}";
            }
        }

        public class RespondentAuthorizeAttribute : AuthorizeAttribute
        {
            public RespondentAuthorizeAttribute()
            {
                Roles = $"{AdminRole},{CreatorRole},{RespondentRole}";
            }
        }

        public static class PermissionChecker
        {
            public static bool HasAccess(int userAccessLevelId, int requiredAccessLevelId)
            {
                return userAccessLevelId <= requiredAccessLevelId;
            }

            public static void ValidateAccess(int userAccessLevelId, int requiredAccessLevelId)
            {
                if (!HasAccess(userAccessLevelId, requiredAccessLevelId))
                {
                    throw new UnauthorizedAccessException("Недостаточно прав");
                }
            }
        }
    }

 
}