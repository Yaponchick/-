Это простое приложение "Конструктор анкет"

## Технологии

- [React](https://react.dev/)
- [TypeScript](https://www.typescriptlang.org/)
- [Redux Toolkit (RTK)](https://redux-toolkit.js.org/)
- [Material UI](https://mui.com/)
- [Webpack](https://webpack.js.org/) (при использовании представленной сборки)
- [ChackJs] (https://www.chartjs.org/)
- ESLint, Prettier, Stylelint

## Структура проекта

```bash
Frontend/
├── .husky/ # Git хуки для автоматизации проверок перед коммитом
├── public/ # Статические файлы и index.html
├── src/│
│	├──api # Api 
│ 	├── app/ # Главные компоненты приложения
│ 	│ 	└── index.tsx
│ 	├── component/ # Компоненты пользовательского интерфейса
│ 	│ 	├──	accessControl # Контроль доступа
│		├── AnswersComponent # Компонент вопросов для ответов
│		├── ButtonMenu # Меню для страницы создания и анализа 
│		├── Modal # Модальные окна
│		├── nav # Навбар
│		├── index.ts 
│ 	│ 	└── todo-list/ # Компонент списка задач
│ 	│ 		└── todo-list.tsx
│ 	├── hook/ # Пользовательские хуки (например, useForm.tsx)
│		└── useAuth # Хук для авторизации
│		└── useDelete # Хук удаления анкеты
│		└── usePublishToggle # Хук для смены состояния анкеты (открыта/закрыта)
│ 	├── pages/ # Страницы приложения
│ 	│ 	└── main/
│ 	├── store/ # Redux-хранилище и слайсы
│ 	│ 	├── todos/ # Слайс для работы с задачами (todoSlice.ts)
│ 	│		└── index.ts # Конфигурация Redux-хранилища
│ 	├── types/ # Общие типы и интерфейсы
│ 	├── index.tsx # Точка входа в приложение
│ 	└── styles.css # Глобальные стили
├── webpack/ # Конфигурация сборщика (Webpack)
├── package.json # Зависимости и скрипты проекта
├── README.md # Документация проекта
└── ...
```

## Установка и запуск

**Предварительные требования**

- Node.js (рекомендуется версия 16.20.2 или выше)
- npm

### Клонирование репозитория

Клонируйте репозиторий на локальную машину:

```bash
git clone https://azure.enplus.group/Development%20Web-Solutions/FormConstructor/_git/FormConstructor

cd Frontend
```

### Установка зависимостей

С использованием npm:

```bash
  npm install
```

### Запуск приложения в режиме разработки

Запустите приложение командой:

```bash
  npm start
```

После успешного запуска приложение будет доступно по адресу: [localhost:3000](http://localhost:3000/)
Сменить порт можно в файле webpack.dev.js
Для смены ссылки отправки запросов на backend прейдите в файл apiClient

### Сборка для продакшена

Для создания оптимизированной сборки выполните:

```bash
  npm run build
```



