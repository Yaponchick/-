import './thanks.css';

function ThkPage() {

    return (
        <div className="Thk-container">
            <div className="survey-pageThk">
                <div className="text-thk">Спасибо!</div>
                <div className="text-bottom">Ваша анкета отправлена</div>

            </div>
        </div>
    );
}

export default ThkPage;