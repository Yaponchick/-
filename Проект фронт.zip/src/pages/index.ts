import Auth from './auth/auth.module';
import Main from './main';
import Pas from './pasRem/resetPassword';
import SurveyPage from './createPage/SurveyPage';
import Navbar from '../component/nav/Navbar';
import Account from './account/Account';
import Answers from './answers/answersPage';
import Thanks from './thanks/thanksPage';
import RepeatedResponse from './repeatedResponse/repeatedResponse';
import Eror404 from './eror/Eror404';
import Eror500 from './eror/Eror500';
import AnalysisPage from './analysis/AnalysisPage';
import AdminPanel from './adminPanel/adminPanel';
import AccessDenied from './accessDenied/accessDenied'

export { Auth, Main, Pas, SurveyPage, 
    Navbar, Account, Answers,Thanks, 
    RepeatedResponse, Eror404, Eror500,
    AnalysisPage, AdminPanel, AccessDenied
};
