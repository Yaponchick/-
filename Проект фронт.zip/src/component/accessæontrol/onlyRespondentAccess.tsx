import React from 'react';
import { Navigate } from 'react-router-dom';
import { getRoleFromToken } from '../../api/apiClient';

export const OnlyRespondent: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const role = getRoleFromToken();
    if (role !== 'Respondent') 
        return <Navigate to="/accessDenied" replace />;
    return <>{children}</>;
};
