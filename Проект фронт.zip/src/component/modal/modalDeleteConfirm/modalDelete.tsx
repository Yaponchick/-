import React, { useState, useEffect } from 'react';

import './modalDeleteStyle.css'

import DeleteIcons from '../../../img/SurveyPage/DeleteIcons.png';

interface ModalDeleteProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void | Promise<boolean>;
    surveyTitle?: string;
}

const ModalDelete: React.FC<ModalDeleteProps> = ({ isOpen, onClose, onConfirm, surveyTitle }) => {

    if (!isOpen) return null;

    const handleConfirm = async () => {
        const success = await onConfirm();
        if (success !== false) {
            onClose();
        }
    }

    return (
        <div className='modal' onClick={onClose}>
            <div className='modal-content' onClick={(e) => e.stopPropagation()}>
                <div className='modal-text'>
                    <div className='confirmText'>
                        Подтверждение
                        <div className="closeIcon">
                            <img src={DeleteIcons} alt="Закрыть" className='closeButtonIcon' onClick={onClose} />
                        </div>
                    </div>
                    <hr />
                    <div className='textModalDel'>
                        Вы действительно желаете удалить анкету?<br />
                        <br />
                        <strong>{surveyTitle}</strong>
                    </div>
                </div>
                <hr />
                <div className='footer-modal'>
                    <button style={{ background: 'rgba(240, 73, 35, 1)', color: 'white' }} className='button-Del-Modal' onClick={handleConfirm}>Да</button>
                    <button style={{ background: 'rgb(95, 212, 11)', color: 'white' }} className='button-Del-Modal' onClick={onClose}>Нет</button>

                </div>
            </div>
        </div>
    );
};

export default ModalDelete;
