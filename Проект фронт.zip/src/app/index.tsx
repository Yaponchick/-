import { Auth, Main, Pas, SurveyPage, Navbar, Account, Answers, Thanks, RepeatedResponse, Eror404, Eror500, AnalysisPage, AdminPanel, AccessDenied } from '../pages';
// import {Respas} from '../pages/ResPas';
import { BrowserRouter as Router, Routes, Route, useLocation, useNavigate } from 'react-router-dom';

import { OnlyAdmin } from '../component/accessСontrol/onlyAdminAccess';
import { OnlyCreatorOrAdmin } from '../component/accessСontrol/onlyCreatorOrAdminAccess';
import { OnlyRespondent } from '../component/accessСontrol/onlyRespondentAccess';
import { useAppDispatch } from '../store/strore';
import { useEffect } from 'react';
import { checkToken } from '../store/auth/actions';
import { OnlyAuth, OnlyUnAuth } from '../component';
import { AuthProvider } from '../api/AuthContext';
import { getRoleFromToken } from '../api/apiClient';

export const App = () => {
	const location = useLocation();
	const state = location.state as { backgroundLocation?: Location };
	const dispatch = useAppDispatch();

	const navigate = useNavigate();
	const role = getRoleFromToken();

	useEffect(() => {
		dispatch(checkToken());
	}, []);

	return (
		// <Router> <Navbar/> location={state?.backgroundLocation || location}
		<>
			<AuthProvider>
				<Navbar />
				<Routes>
					<Route path='/' element={<OnlyAuth component={<Main />} />} />
					<Route path='/auth' element={<Auth />} />
					<Route path='/resPassword' element={<Pas />} />
					<Route path='AccessDenied' element={<AccessDenied />} />
					<Route path="/Answers/:id" element={<Answers />} />
					<Route path="/Thanks" element={<Thanks />} />
					<Route path="/RepeatedResponse" element={<RepeatedResponse />} />
					
					<Route path='/SurveyPage' element={
						<OnlyCreatorOrAdmin>
							<SurveyPage />
						</OnlyCreatorOrAdmin>
					} />
					<Route path='/Account' element={
						<OnlyCreatorOrAdmin>
							<Account />
						</OnlyCreatorOrAdmin>
					} />
					<Route path="/Eror500" element={
						<OnlyCreatorOrAdmin>
							<Eror500 />
						</OnlyCreatorOrAdmin>

					} />
					<Route path="/AnalysisPage/:id" element={
						<OnlyCreatorOrAdmin>
							<AnalysisPage />
						</OnlyCreatorOrAdmin>
					} />
					<Route path='/edit-survey/:surveyId' element={
						<OnlyCreatorOrAdmin>
							<SurveyPage />
						</OnlyCreatorOrAdmin>
					} />
					<Route path="/AdminPanel"
						element={
							<OnlyAdmin>
								<AdminPanel />
							</OnlyAdmin>
						} />
					<Route path="*" element={<Eror404 />} />
				</Routes>
			</AuthProvider>
		</>

	);
};