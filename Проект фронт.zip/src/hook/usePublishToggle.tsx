import { useState } from 'react';
import apiClient from '../api/apiClient';

export const usePublishToggle = (initialStatus: boolean = false, id?: string) => {
    const [isPublished, setIsPublished] = useState<boolean>(initialStatus);

    const handleTogglePublish = async () => {
        if (!id) return;

        try {
            await apiClient.put(`/questionnaire/${id}/status`, { IsPublished: !isPublished });
            setIsPublished(prev => !prev);

        } catch (error: any) {
            console.error('Ошибка при изменении статуса:', error);
        }
    };

    return { isPublished, setIsPublished, handleTogglePublish };
};