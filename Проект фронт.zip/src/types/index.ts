import { Todo } from './todos';

export type { Todo };
